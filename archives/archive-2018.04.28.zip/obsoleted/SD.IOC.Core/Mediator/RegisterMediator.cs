﻿namespace SD.IOC.Core.Mediator
{
    /// <summary>
    /// 注册中介者
    /// </summary>
    public static class RegisterMediator
    {

    }
}
